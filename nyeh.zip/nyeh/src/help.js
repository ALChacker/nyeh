const help = (prefix) => {
	return `                
┏━━━°❀ ❬ Hi ❭ ❀°━━━┓
┃❉ Hi. *${id.split("@s.whatsapp.net")[0]}* ❉
┃❉ Berikut Menu Dari *NewalBotツ* ❉
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *${prefix}donasi*
┣❉ *${prefix}nulis*
┗❉ *${prefix}info*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker/stiker*
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┃
┣━━━°❀ ❬ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ❭ ❀°━━⊱
┃
┣➥ *yt* [link]
┃
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}add* [62xxx]
┣➥ *${prefix}kick* [tag]┣
┣➥ *${prefix}kickall* [tag]
┣➥ *${prefix}tagall*
┣➥ *${prefix}welcome* [1/0]
┣➥ *${prefix}nsfw* [1/0]
┣➥ *${prefix}simih* [1/0]
┃
┣━━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}bc* 
┣➥ *${prefix}leave*
┣➥ *${prefix}clearall*
┣➥ *${prefix}setprefix*
┣➥ *${prefix}clone* [tag]
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┃
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}listadmin*
┣➥ *${prefix}blocklist*
┣➥ *${prefix}simi*
┣➥ *${prefix}wait*
┣➥ *${prefix}tiktokstalk* (eror)
┣➥ *${prefix}url2img* (eror)
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help



  
