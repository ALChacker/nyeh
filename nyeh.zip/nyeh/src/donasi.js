const donasi = (prefix) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 ❉⊰━━✿
┃  
┣➥ *SAWERIA* : https://saweria.co/Newal
┃
┣━━━━━━━━━━━━━━━━━━━━
┃            _*NewalBotツ*_
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi